/*
 * ADC.h
 *
 * Created: 1/31/2023 7:54:48 PM
 *  Author: DELL
 */ 

void ADC_intilization(int adc_number);
int ADC_READ();
